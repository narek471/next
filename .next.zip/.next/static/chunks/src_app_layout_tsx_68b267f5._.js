(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/[root-of-the-server]__2794e332._.css",
  "static/chunks/_698e51b9._.js",
  "static/chunks/node_modules_next_3f48ce4d._.js",
  "static/chunks/node_modules_motion-dom_dist_es_ed5d7820._.js",
  "static/chunks/node_modules_framer-motion_dist_es_c4413217._.js",
  "static/chunks/node_modules_0b01d0bc._.js"
],
    source: "dynamic"
});
